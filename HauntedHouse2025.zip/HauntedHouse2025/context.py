# context.py
from house_state import HouseState
house = HouseState()
