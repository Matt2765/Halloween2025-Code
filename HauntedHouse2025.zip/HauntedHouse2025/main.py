# main.py
if __name__ == "__main__":
    from control.system import initialize_system

    # Step 1: Initialize system
    initialize_system()
