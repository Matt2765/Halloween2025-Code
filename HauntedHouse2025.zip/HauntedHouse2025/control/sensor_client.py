# sensor_client.py
# Client API for your main Haunted House process.
# Starts remote_sensor_monitor.py in a child process and exposes one-liners:
#   start_monitor(port=None, baud=921600)
#   get_value("TOF1", "dist_mm", default=None, max_age_ms=250)
#   get("TOF1") -> full dict or None
#   stop_monitor()

from __future__ import annotations
import multiprocessing as mp
from multiprocessing.managers import SyncManager
from typing import Optional, Any, Dict
import time

# Import the monitor module (same folder)
import remote_sensor_monitor as rsm

_manager: Optional[SyncManager] = None
_proc: Optional[mp.Process] = None
_shared: Optional[Dict[str, dict]] = None

def _init_manager() -> SyncManager:
    global _manager
    if _manager is None:
        _manager = mp.Manager()
    return _manager

def start_monitor(port: Optional[str]=None, baud: int=rsm.DEFAULT_BAUD) -> None:
    """Start the monitor process (idempotent)."""
    global _proc, _shared
    if _proc and _proc.is_alive():
        return
    mgr = _init_manager()
    _shared = mgr.dict()  # type: ignore
    _proc = mp.Process(target=rsm.monitor_main, args=(_shared, port, baud), daemon=True)
    _proc.start()
    # small warmup
    time.sleep(0.25)

def stop_monitor() -> None:
    global _proc, _manager
    if _proc and _proc.is_alive():
        _proc.terminate()
        _proc.join(timeout=1.0)
    _proc = None
    # keep manager alive for access until program end

def get(sensor_id: str) -> Optional[dict]:
    """Return the full record for a sensor id, or None if missing."""
    if not _shared: return None
    return _shared.get(sensor_id)

def get_value(sensor_id: str, key: str, default: Any=None, max_age_ms: Optional[int]=250) -> Any:
    """
    One-liner: fetch sensors[sid]['vals'][key], with optional staleness guard.
    max_age_ms=None to skip age check.
    """
    rec = get(sensor_id)
    if not rec: return default
    if max_age_ms is not None:
        t_host_ms = rec.get("t_host_ms", 0)
        if (int(time.monotonic()*1000) - int(t_host_ms)) > max_age_ms:
            return default
    vals = rec.get("vals") or {}
    return vals.get(key, default)

def get_latency_ms(sensor_id: str) -> Optional[int]:
    """Approx latency ~= receiver_rx_ms - sender_t_ms (both millis from sender’s perspective)."""
    rec = get(sensor_id)
    if not rec: return None
    t_send = int(rec.get("t_send_ms", 0))
    t_rx   = int(rec.get("t_rx_ms", 0))
    if t_send <= 0 or t_rx <= 0: return None
    return max(0, t_rx - t_send)

# Example usage (run this file directly to test quickly):
if __name__ == "__main__":
    start_monitor()  # auto-detect receiver port
    print("[sensor_client] Monitoring… Ctrl+C to quit.")
    try:
        while True:
            v = get_value("TOF1", "dist_mm", default=None, max_age_ms=500)
            if v is not None:
                print("TOF1 dist_mm:", v)
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        stop_monitor()
