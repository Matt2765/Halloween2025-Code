# remote_sensor_monitor.py
# Runs in a child process. Reads NDJSON from the ESP32 receiver (USB Serial),
# parses packets, and updates a shared Manager dict keyed by sensor id.
# Expected receiver line shape:
# {"rx_ms":123456,"mac":"AA:BB:...","data":{"id":"TOF1","seq":42,"t":123400,"vals":{"dist_mm":823,"status":0}}}

from __future__ import annotations
import json, time, sys
from typing import Dict, Any, Optional
try:
    import serial, serial.tools.list_ports
except ImportError:
    raise SystemExit("pyserial not installed. pip install pyserial")

DEFAULT_BAUD = 921600
PORT_HINTS = ("Silicon Labs", "CP210", "CH340", "USB-SERIAL", "ESP32", "WCH")

def _now_ms() -> int:
    return int(time.monotonic() * 1000)

def autodetect_port() -> Optional[str]:
    for p in serial.tools.list_ports.comports():
        desc = f"{p.device} {p.description} {p.manufacturer or ''}"
        if any(k.lower() in desc.lower() for k in PORT_HINTS):
            return p.device
    # fallback: first available
    ports = list(serial.tools.list_ports.comports())
    return ports[0].device if ports else None

def open_serial(port: Optional[str], baud: int) -> serial.Serial:
    if not port:
        port = autodetect_port()
    if not port:
        raise RuntimeError("No serial ports found for receiver.")
    return serial.Serial(port=port, baudrate=baud, timeout=0.05)

def monitor_main(shared: "dict[str, dict]", port: Optional[str]=None, baud: int=DEFAULT_BAUD) -> None:
    """Main loop. Updates shared[sensor_id] = {...} many times/sec."""
    backoff = 0.25
    while True:
        try:
            ser = open_serial(port, baud)
            # Small announcement so you can see which port it grabbed.
            sys.stderr.write(f"[RemoteSensorMonitor] Connected {ser.port} @ {baud}\n")
            sys.stderr.flush()
            buff = bytearray()
            last_line_ms = _now_ms()
            while True:
                chunk = ser.read(4096)
                if chunk:
                    buff.extend(chunk)
                    # Split by lines (NDJSON)
                    while True:
                        nl = buff.find(b"\n")
                        if nl < 0: break
                        line = buff[:nl].decode("utf-8", "ignore").strip()
                        del buff[:nl+1]
                        if not line: continue
                        last_line_ms = _now_ms()
                        try:
                            obj = json.loads(line)
                            rx_ms = int(obj.get("rx_ms", _now_ms()))
                            mac   = obj.get("mac", "")
                            data  = obj.get("data") or {}
                            sid   = data.get("id")
                            seq   = int(data.get("seq", 0))
                            t_send= int(data.get("t", 0))
                            vals  = data.get("vals") or {}
                            if not sid: 
                                continue
                            shared[sid] = {
                                "id": sid,
                                "seq": seq,
                                "t_send_ms": t_send,   # sender millis()
                                "t_rx_ms": rx_ms,      # receiver millis()
                                "t_host_ms": _now_ms(),# this process timestamp
                                "mac": mac,
                                "vals": vals
                            }
                        except Exception:
                            # Keep running on bad line
                            pass
                # basic link watchdog, try reconnect if silent for a while
                if _now_ms() - last_line_ms > 5000:
                    raise RuntimeError("Serial silent; reconnecting")
        except Exception as e:
            sys.stderr.write(f"[RemoteSensorMonitor] {type(e).__name__}: {e}\n")
            sys.stderr.flush()
            time.sleep(backoff)
            backoff = min(backoff*2, 5.0)
            # loop and retry; shared dict persists across reconnects
            continue
